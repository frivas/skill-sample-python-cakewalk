# Introduction
This is a Python version of the Cake Walk Alexa Skill. There is already a NodeJS version of it with a great explanation [here](https://developer.amazon.com/alexa-skills-kit/courses/cake-walk).

There are a few things I would like to point out of this version:

1. There is no official support for S3 in Python’s ASK SDK, so I used one that I wrote sometime ago with a couple of changes:
- I had fixed an error in the function that gets the userID from the handler_input object.
- I added support for ApiClient to the 